from django.shortcuts import render

from . import logic


def render_index(request):
    tasks = logic.get_all_tasks()
    items = logic.get_all_items()

    template_args = {
        'tasks': tasks,
        'items': items,
        # 'items': logic.get_all_items_for_task(task),
    }
    return render(request, 'todo/index.html', template_args)
